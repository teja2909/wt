package com.example;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get username and password from URL parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // For demonstration purposes, we're using hardcoded values
        // In a real application, you would check these against a database
        if ("admin".equals(username) && "admin123".equals(password)) {
            // Redirect to welcome page with username as a parameter
            response.sendRedirect("welcome.jsp?username=" + username);
        } else {
            // Redirect back to login with an error message
            response.sendRedirect("login.jsp?error=invalid");
        }
    }
}
