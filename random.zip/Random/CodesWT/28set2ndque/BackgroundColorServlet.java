import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class BackgroundColorServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the content type
        response.setContentType("text/html");

        // Get the user input color from the request parameters
        String color = request.getParameter("color");
        if (color == null) {
            color = "white"; // Default color if no input is provided
        }

        // Print the HTML page with the background color set by the user
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Set Background Color</title></head>");
        out.println("<body style='background-color:" + color + ";'>");
        out.println("<h2>Page with Background Color: " + color + "</h2>");
        out.println("<form method='get'>");
        out.println("Enter background color: <input type='text' name='color' placeholder='e.g., red, blue, #ff0000'>");
        out.println("<input type='submit' value='Set Color'>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }
}
