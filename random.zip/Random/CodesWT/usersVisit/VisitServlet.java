import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/VisitServlet")
public class VisitServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set content type for the response
        response.setContentType("text/html");

        // Check for the visit count cookie
        Cookie[] cookies = request.getCookies();
        int visitCount = 1; // Default to 1 if this is the first visit
        boolean isReturningUser = false;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visitCount")) {
                    visitCount = Integer.parseInt(cookie.getValue()) + 1;
                    isReturningUser = true;
                    break;
                }
            }
        }

        // Set the updated visit count in the cookie
        Cookie visitCountCookie = new Cookie("visitCount", Integer.toString(visitCount));
        visitCountCookie.setMaxAge(60 * 60 * 24 * 30); // Cookie expires in 30 days
        response.addCookie(visitCountCookie);

        // Generate the response HTML
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Session Tracking with Cookies</h2>");
        if (isReturningUser) {
            response.getWriter().println("<p>Welcome back! This is your visit number: " + visitCount + "</p>");
        } else {
            response.getWriter().println("<p>Welcome! This seems to be your first visit.</p>");
        }
        response.getWriter().println("</body></html>");
    }
}
