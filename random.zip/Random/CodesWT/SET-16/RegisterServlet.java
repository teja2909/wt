import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String DB_USER = "yourDatabaseUser";
    private static final String DB_PASSWORD = "yourDatabasePassword";
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (username == null || password == null || email == null ||
                username.isEmpty() || password.isEmpty() || email.isEmpty()) {
            out.println("<p style='color:red;'>All fields are required!</p>");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
       
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
        
            String query = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, email);
            
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                out.println("<p style='color:green;'>Registration successful!</p>");
                out.println("<a href='login.jsp'>Go to Login</a>");
            } else {
                out.println("<p style='color:red;'>Registration failed. Please try again.</p>");
            }
            
        } catch (ClassNotFoundException e) {
            out.println("<p style='color:red;'>Error loading database driver: " + e.getMessage() + "</p>");
        } catch (SQLException e) {
            out.println("<p style='color:red;'>Database error: " + e.getMessage() + "</p>");
        } finally {
            
            if (stmt != null) try { stmt.close(); } catch (SQLException ignore) {}
            if (conn != null) try { conn.close(); } catch (SQLException ignore) {}
        }
    }
}
