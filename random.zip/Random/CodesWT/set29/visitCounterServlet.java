package com.example;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/VisitCounterServlet")
public class VisitCounterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session or create a new one
        HttpSession session = request.getSession(true);

        // Initialize visit count if not already set
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 0; // First visit
        }

        // Increment visit count
        visitCount++;
        session.setAttribute("visitCount", visitCount);

        // Set response content type
        response.setContentType("text/html");

        // Generate HTML response
        response.getWriter().println("<html><head><title>Visit Counter</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h2>Welcome to the Visit Counter!</h2>");
        response.getWriter().println("<p>You have visited this page " + visitCount + " times.</p>");
        response.getWriter().println("<a href='VisitCounterServlet'>Refresh</a>");
        response.getWriter().println("</body></html>");
    }
}
