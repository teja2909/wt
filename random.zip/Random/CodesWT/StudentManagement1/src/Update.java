import java.sql.*;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class Update extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String t = request.getParameter("year");
        String rollNo = request.getParameter("roll");
        String name = request.getParameter("name");
        
        try {
            int sub1 = Integer.parseInt(request.getParameter("sub1"));
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");
            PreparedStatement pst = con.prepareStatement(
                    "UPDATE " + t + " SET name = ?, sub1 = ?, WHERE roll = ?");
            pst.setString(6, rollNo);
            pst.setString(1, name);
            pst.setInt(2, sub1);
            int i = pst.executeUpdate();
            out.println("<link rel='stylesheet' type='text/css' href='style.css'>");
            out.println("<div class='container'>");
            if (i > 0) {
                out.println("<h1>Record updated successfully</h1>");
                out.println("<a href='index.html'>Home</a>");
            } else {
                out.println("<h1>Record not updated</h1>");
                out.println("<a href='index.html'>Home</a>");
            }
        } catch (Exception e) {
            out.println(e);
            out.println("<a href='index.html'>Home</a>");
        }
    }
}
