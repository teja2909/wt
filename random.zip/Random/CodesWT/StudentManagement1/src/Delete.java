

import java.sql.*;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class Delete extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String t = request.getParameter("year");
        String rollNo = request.getParameter("roll");
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");
            PreparedStatement pst = con.prepareStatement("DELETE FROM " + t + " WHERE roll = ?");
            pst.setString(1, rollNo);
            int i = pst.executeUpdate();
            out.println("<link rel='stylesheet' type='text/css' href='style.css'>");
            out.println("<div class='container'>");
            if (i > 0) {
                out.println("<h1>Record deleted successfully</h1>");
                out.println("<a href='index.html'>Home</a>");
            } else {
                out.println("<h1>Record not deleted</h1>");
                out.println("<a href='index.html'>Home</a>");
            }
        } catch (Exception e) {
            out.println(e);
        }
    }
}
