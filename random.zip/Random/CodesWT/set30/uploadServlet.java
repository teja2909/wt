package com.example;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/UploadServlet")
@MultipartConfig
public class UploadServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dbUrl = "jdbc:mysql://localhost:3306/ImageUploadDB";
        String dbUser = "yourUsername"; // Replace with your database username
        String dbPassword = "yourPassword"; // Replace with your database password

        // Get the file part from the request
        Part filePart = request.getPart("image");
        String fileName = filePart.getSubmittedFileName();

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            // Prepare the SQL statement
            String sql = "INSERT INTO Images (image, imageName) VALUES (?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            // Set the image as a stream
            InputStream inputStream = filePart.getInputStream();
            preparedStatement.setBlob(1, inputStream);
            preparedStatement.setString(2, fileName);

            // Execute the statement
            int row = preparedStatement.executeUpdate();
            if (row > 0) {
                response.getWriter().println("Image uploaded successfully!");
            } else {
                response.getWriter().println("Failed to upload image.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
