import java.sql.*;

public class UpdateProduct {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/your_database";
        String username = "your_username";
        String password = "your_password";

        String updateQuery = "UPDATE product SET price = ? WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {

            // Set parameters
            preparedStatement.setBigDecimal(1, new java.math.BigDecimal("1200.00")); // New price
            preparedStatement.setInt(2, 2); // Product ID = 2

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("A product was updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
