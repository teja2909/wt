import java.sql.*;

public class DisplayProducts {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
        String username = "system";
        String password = "system";

        String selectQuery = "SELECT * FROM product";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {

            // Display table header
            System.out.println("=".repeat(50));
            System.out.printf("%-10s %-20s %-15s%n", "ID", "Name", "Price");
            System.out.println("=".repeat(50));

            // Display rows
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");

                System.out.printf("%-10d %-20s %-15.2f%n", id, name, price);
            }

            System.out.println("=".repeat(50));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
