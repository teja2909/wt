import java.sql.*;

public class Transaction {
    public static void main(String[] args) {
        // Oracle database connection details
        String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe"; // Replace 'xe' with your Oracle SID
        String username = "system"; // Oracle username
        String password = "system"; // Oracle password

        // SQL queries for transaction
        String insertQuery = "INSERT INTO product (id, name, price) VALUES (?, ?, ?)";
        String updateQuery = "UPDATE product SET price = ? WHERE id = ?";
        String deleteQuery = "DELETE FROM product WHERE id = ?";

        try (
            // Establish connection
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);
        ) {
            // Disable auto-commit for transaction management
            connection.setAutoCommit(false);

            // Insert operation
            try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                insertStmt.setInt(1, 101); // Product ID
                insertStmt.setString(2, "Tablet"); // Product Name
                insertStmt.setBigDecimal(3, new java.math.BigDecimal("600.00")); // Product Price
                insertStmt.executeUpdate();
                System.out.println("Insert operation successful.");
            }

            // Update operation
            try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                updateStmt.setBigDecimal(1, new java.math.BigDecimal("650.00")); // New Price
                updateStmt.setInt(2, 101); // Product ID to update
                updateStmt.executeUpdate();
                System.out.println("Update operation successful.");
            }

            // Delete operation
            try (PreparedStatement deleteStmt = connection.prepareStatement(deleteQuery)) {
                deleteStmt.setInt(1, 102); // Product ID to delete
                deleteStmt.executeUpdate();
                System.out.println("Delete operation successful.");
            }

            // Commit the transaction
            connection.commit();
            System.out.println("Transaction committed successfully.");

        } catch (SQLException e) {
            // Rollback the transaction in case of an error
            try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
                System.err.println("Transaction failed. Rolling back changes.");
                connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
        }
    }
}
