import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/FormServlet")
public class FormServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        // Set attributes to be accessed on the display page
        request.setAttribute("name", name);
        request.setAttribute("email", email);

        // Forward the request to display.jsp
        request.getRequestDispatcher("display.jsp").forward(request, response);
    }
}
