package com.example;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProcessFormServlet")
public class ProcessFormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        // Define the file to write to
        String filePath = "C:\\path\\to\\your\\output\\data.txt"; // Update this to your desired file path

        // Write the data to a file
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath, true))) {
            writer.println("Name: " + name);
            writer.println("Email: " + email);
            writer.println("-----------------------------");
        } catch (IOException e) {
            e.printStackTrace();
            response.getWriter().println("Error writing to file: " + e.getMessage());
            return;
        }

        // Set response content type
        response.setContentType("text/html");

        // Generate HTML response
        response.getWriter().println("<html><head><title>Form Submission</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h2>Data Submitted Successfully!</h2>");
        response.getWriter().println("<p>Name: " + name + "</p>");
        response.getWriter().println("<p>Email: " + email + "</p>");
        response.getWriter().println("<a href='form.jsp'>Go Back</a>");
        response.getWriter().println("</body></html>");
    }
}
