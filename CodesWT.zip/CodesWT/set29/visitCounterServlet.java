import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/VisitCounterServlet")
public class VisitCounterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html");

        // Get the user's session, or create one if it doesn't exist
        HttpSession session = request.getSession(true);

        // Retrieve the visit count from the session
        Integer visitCount = (Integer) session.getAttribute("visitCount");

        // Initialize visit count if it is the first visit
        if (visitCount == null) {
            visitCount = 1;
        } else {
            // Increment visit count if user has already visited
            visitCount++;
        }

        // Update the session attribute with the new visit count
        session.setAttribute("visitCount", visitCount);

        // Write output to the client
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Welcome to the Visit Counter Servlet!</h2>");
        out.println("<p>You have visited this page " + visitCount + " times.</p>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Forward POST requests to the doGet method
        doGet(request, response);
    }
}
