import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;

@WebServlet("/GenerateFileServlet")
public class GenerateFileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve user input
        String username = request.getParameter("username");
        String content = request.getParameter("content");

        // Path to save the generated file
        String filePath = getServletContext().getRealPath("/") + "userContent.txt";

        // Use a FileOutputStream to write to the file
        try (FileOutputStream fos = new FileOutputStream(filePath);
             PrintWriter writer = new PrintWriter(fos)) {

            // Write user input to the file
            writer.println("User Input:");
            writer.println("Username: " + username);
            writer.println("Content: " + content);
            writer.println();

            // Retrieve additional records from the database
            try (Connection connection = DBConnection.getConnection()) {
                String sql = "SELECT username, data, created_at FROM user_records";
                PreparedStatement stmt = connection.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();

                writer.println("Database Records:");
                while (rs.next()) {
                    writer.println("Username: " + rs.getString("username"));
                    writer.println("Data: " + rs.getString("data"));
                    writer.println("Created At: " + rs.getTimestamp("created_at"));
                    writer.println();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error writing file");
            return;
        }

        // Provide feedback to the user
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>File has been generated successfully!</h2>");
        out.println("<p>File Location: " + filePath + "</p>");
        out.println("<a href='" + request.getContextPath() + "/userContent.txt'>Download the file</a>");
        out.println("</body></html>");
    }
}
