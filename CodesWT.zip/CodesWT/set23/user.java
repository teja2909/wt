package com.example;

public class User {
    private String username;
    private String email;

    // Constructor
    public User(String username, String email) {
        this.username = username;
        this.email = email;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }
}
// Create a Java class named User.java. This class will represent the user data and should be placed in the appropriate package (e.g., com.example).