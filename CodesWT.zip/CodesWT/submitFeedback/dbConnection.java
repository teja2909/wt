import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/feedbackDB";
    private static final String USER = "yourUsername"; // Replace with DB username
    private static final String PASSWORD = "yourPassword"; // Replace with DB password

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}

//  CREATE DATABASE feedbackDB;

// USE feedbackDB;

// CREATE TABLE feedback (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     username VARCHAR(100) NOT NULL,
//     comment TEXT NOT NULL,
//     timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// );
