import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/SessionManagementServlet")
public class SessionManagementServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(true);
        
       
        Integer interactionCount = (Integer) session.getAttribute("interactionCount");
        if (interactionCount == null) {
            interactionCount = 0;
        }
        
        interactionCount++;
        session.setAttribute("interactionCount", interactionCount);
   
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Session Management with URL Rewriting</title></head>");
        out.println("<body>");
        out.println("<h2>Session Management Example with URL Rewriting</h2>");
        out.println("<p>Welcome back! You have visited this page " + interactionCount + " times in this session.</p>");
        
        String nextPageURL = response.encodeURL("SessionManagementServlet");
        out.println("<a href=\"" + nextPageURL + "\">Refresh Page</a>");
        out.println("</body>");
        out.println("</html>");
    }
}
